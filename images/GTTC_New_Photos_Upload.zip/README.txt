GTTC new industrial visit photos

Upload all JPG files in this images folder to the images/ folder in the GitHub repository.
The filenames are numbered to preserve upload order; update the GTTC gallery HTML to reference these names after upload.
